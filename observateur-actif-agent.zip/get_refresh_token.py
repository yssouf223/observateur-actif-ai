"""À lancer UNE FOIS sur votre ordinateur pour obtenir le refresh token YouTube.
Prérequis : client_secret.json (OAuth « Application de bureau ») dans le même dossier.
pip install google-auth-oauthlib"""
from google_auth_oauthlib.flow import InstalledAppFlow

flow = InstalledAppFlow.from_client_secrets_file(
    "client_secret.json", ["https://www.googleapis.com/auth/youtube.upload"])
creds = flow.run_local_server(port=0, access_type="offline", prompt="consent")
print("\nYT_CLIENT_ID     =", creds.client_id)
print("YT_CLIENT_SECRET =", creds.client_secret)
print("YT_REFRESH_TOKEN =", creds.refresh_token)
