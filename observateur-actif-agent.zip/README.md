# Observateur Actif – Agent Shorts quotidien

Chaque jour : recherche d'une histoire insolite d'Afrique → script (Gemini) → voix (edge-tts)
→ vidéos de fond (Pexels) + sous-titres + musique → publication YouTube → alerte Telegram.

## Structure du dépôt
```
main.py
requirements.txt
used.json                    (historique, commence vide : [])
.gitignore
music/                       (optionnel : vos mp3 libres de droits)
.github/workflows/daily.yml
get_refresh_token.py         (à lancer une seule fois sur votre ordinateur)
```

## 1. Clés gratuites
- **Gemini** : aistudio.google.com → Get API key → `GEMINI_API_KEY`
- **Pexels** : pexels.com/api → `PEXELS_API_KEY`

## 2. YouTube
1. console.cloud.google.com → nouveau projet → activer **YouTube Data API v3**.
2. Écran de consentement OAuth → type Externe → remplir le minimum → **Publier l'application (En production)**.
   (En mode Test, le token expire après 7 jours.)
3. Identifiants → Créer → ID client OAuth → **Application de bureau** → télécharger le JSON,
   le renommer `client_secret.json`.
4. Sur votre ordinateur : `pip install google-auth-oauthlib` puis `python get_refresh_token.py`.
   Connectez-vous avec le compte de la chaîne Observateur Actif.
   Notez `YT_CLIENT_ID`, `YT_CLIENT_SECRET`, `YT_REFRESH_TOKEN`.
   (Un avertissement « application non vérifiée » est normal : Avancé → Continuer.)

## 3. Alerte Telegram (optionnelle)
1. Dans Telegram, parlez à **@BotFather** → `/newbot` → copiez le token → `TELEGRAM_BOT_TOKEN`.
2. Envoyez un message quelconque à votre nouveau bot.
3. Ouvrez `https://api.telegram.org/bot<TOKEN>/getUpdates` dans un navigateur et copiez
   `"chat":{"id": ...}` → `TELEGRAM_CHAT_ID`.

## 4. GitHub
1. Créez un dépôt **privé** et envoyez-y tous les fichiers de ce dossier.
2. Settings → Secrets and variables → Actions → New repository secret, pour chacun de :
   `GEMINI_API_KEY`, `PEXELS_API_KEY`, `YT_CLIENT_ID`, `YT_CLIENT_SECRET`, `YT_REFRESH_TOKEN`,
   `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`.
3. Onglet Actions → « Short quotidien » → Run workflow (test). La vidéo est publiée en **privé**.
4. Quand le résultat vous convient, dans `.github/workflows/daily.yml` remplacez
   `PRIVACY_STATUS: private` par `PRIVACY_STATUS: public`.

## Musique
- Par défaut, une ambiance sombre est **générée par le code** (aucun droit d'auteur).
- Pour utiliser vos propres musiques : déposez des `.mp3`/`.wav` **libres de droits** dans `music/`
  (ex. YouTube Audio Library, Pixabay Music). Une est choisie au hasard chaque jour.

## Réglages (variables d'environnement)
- `GEMINI_MODEL` (défaut `gemini-2.5-flash`), `TTS_VOICE` (défaut `fr-FR-HenriNeural`).
- Autre voix : `fr-FR-DeniseNeural`, `fr-FR-RemyMultilingualNeural`.

## Bon à savoir
- Relisez les premières vidéos : l'IA ne lit que titres et résumés d'actualité.
- Si YouTube force les vidéos en privé (projet API non vérifié), demandez l'audit de l'API.
- Cochez « contenu modifié ou synthétique » dans YouTube Studio si demandé.
